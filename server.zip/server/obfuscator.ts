import * as luaparse from "luaparse";
import type { ObfuscationOptions } from "@shared/schema";

// Generate random identifier
function generateRandomId(prefix: string = "_", length: number = 8): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";
  let result = prefix;
  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

// Encode strings using UTF-8 byte-based obfuscation
function encodeString(str: string): string {
  // Convert string to UTF-8 bytes (handles all Unicode properly)
  const encoder = new TextEncoder();
  const utf8Bytes = encoder.encode(str);
  
  // Split into chunks if too long to avoid Lua line limits
  if (utf8Bytes.length > 200) {
    const chunks: string[] = [];
    for (let i = 0; i < utf8Bytes.length; i += 200) {
      const chunk = Array.from(utf8Bytes.slice(i, i + 200));
      chunks.push(`string.char(${chunk.join(',')})`);
    }
    return chunks.join('..');
  }
  
  const bytes = Array.from(utf8Bytes);
  return `string.char(${bytes.join(',')})`;
}

export function obfuscateLuaCode(code: string, options: ObfuscationOptions): string {
  try {
    // Step 1: Remove comments first (if enabled)
    let processedCode = code;
    if (options.removeComments) {
      processedCode = processedCode
        .replace(/--\[\[[\s\S]*?\]\]/g, '') // Multi-line comments
        .replace(/--[^\n]*/g, ''); // Single-line comments
    }

    // Parse the Lua code
    const ast = luaparse.parse(processedCode, {
      locations: true,
      ranges: true,
      scope: true,
    }) as any;

    // Track variable and function name mappings
    const nameMap = new Map<string, string>();
    const usedNames = new Set<string>();
    
    // Lua reserved keywords and common globals that shouldn't be renamed
    const reservedKeywords = new Set([
      'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function',
      'if', 'in', 'local', 'nil', 'not', 'or', 'repeat', 'return', 'then',
      'true', 'until', 'while', 'goto',
      // Common Lua globals
      'print', 'pairs', 'ipairs', 'type', 'tonumber', 'tostring', 'require',
      'assert', 'error', 'pcall', 'xpcall', 'select', 'next', 'rawget', 'rawset',
      'setmetatable', 'getmetatable', 'table', 'string', 'math', 'io', 'os',
      'debug', 'coroutine', 'package', 'bit32', 'utf8', '_G', '_VERSION',
      'loadstring', 'load', 'dofile', 'loadfile', 'collectgarbage', 'unpack'
    ]);

    // Get or create obfuscated name
    function getObfuscatedName(original: string): string {
      if (reservedKeywords.has(original)) {
        return original;
      }
      
      if (!nameMap.has(original)) {
        let newName: string;
        do {
          newName = generateRandomId('_', 6);
        } while (usedNames.has(newName) || reservedKeywords.has(newName));
        
        nameMap.set(original, newName);
        usedNames.add(newName);
      }
      
      return nameMap.get(original)!;
    }

    // Collect all identifiers that should be renamed
    function collectIdentifiers(node: any, inLocal: boolean = false): void {
      if (!node || typeof node !== 'object') return;

      // Local variable declarations
      if (node.type === 'LocalStatement' && options.renameVariables) {
        if (node.variables) {
          node.variables.forEach((variable: any) => {
            if (variable.type === 'Identifier' && variable.name) {
              getObfuscatedName(variable.name);
            }
          });
        }
      }

      // Function declarations
      if (node.type === 'FunctionDeclaration' && options.renameFunctions) {
        if (node.identifier && node.identifier.type === 'Identifier') {
          if (node.isLocal) {
            getObfuscatedName(node.identifier.name);
          }
        }
        // Function parameters
        if (node.parameters && options.renameVariables) {
          node.parameters.forEach((param: any) => {
            if (param.type === 'Identifier' && param.name) {
              getObfuscatedName(param.name);
            }
          });
        }
      }

      // Assignment to new variables
      if (node.type === 'AssignmentStatement' && options.renameVariables) {
        if (node.variables) {
          node.variables.forEach((variable: any) => {
            if (variable.type === 'Identifier' && variable.name && !reservedKeywords.has(variable.name)) {
              // Only register if it's not already a global
              getObfuscatedName(variable.name);
            }
          });
        }
      }

      // Recurse through all child nodes
      for (const key in node) {
        if (key === 'parent') continue;
        const value = node[key];
        if (Array.isArray(value)) {
          value.forEach(child => collectIdentifiers(child, inLocal));
        } else if (value && typeof value === 'object') {
          collectIdentifiers(value, inLocal);
        }
      }
    }

    // Collect all identifiers first
    collectIdentifiers(ast);

    // Collect all replacements to apply
    const replacements: Array<{ start: number; end: number; replacement: string }> = [];

    function collectReplacements(node: any): void {
      if (!node || typeof node !== 'object') return;

      // Replace identifiers
      if (node.type === 'Identifier' && node.range) {
        const obfuscated = nameMap.get(node.name);
        if (obfuscated && obfuscated !== node.name) {
          replacements.push({
            start: node.range[0],
            end: node.range[1],
            replacement: obfuscated,
          });
        }
      }

      // Replace string literals
      if (node.type === 'StringLiteral' && node.range && node.value !== undefined && options.encodeStrings) {
        // Encode ALL strings for maximum obfuscation
        const encoded = encodeString(node.value);
        replacements.push({
          start: node.range[0],
          end: node.range[1],
          replacement: encoded,
        });
      }

      // Recurse through all child nodes
      for (const key in node) {
        if (key === 'parent') continue;
        const value = node[key];
        if (Array.isArray(value)) {
          value.forEach(child => collectReplacements(child));
        } else if (value && typeof value === 'object') {
          collectReplacements(value);
        }
      }
    }

    collectReplacements(ast);

    // Apply replacements from end to start to maintain positions
    replacements.sort((a, b) => b.start - a.start);
    let obfuscatedCode = processedCode;
    
    for (const { start, end, replacement } of replacements) {
      obfuscatedCode = obfuscatedCode.slice(0, start) + replacement + obfuscatedCode.slice(end);
    }

    // Minify whitespace carefully (preserve necessary spaces)
    if (options.minifyWhitespace) {
      obfuscatedCode = obfuscatedCode
        // Remove leading/trailing whitespace from lines
        .split('\n')
        .map(line => line.trim())
        .join('\n')
        // Remove empty lines
        .replace(/\n+/g, '\n')
        // But keep single spaces between keywords and identifiers
        .replace(/([a-zA-Z0-9_])\s+([a-zA-Z0-9_])/g, '$1 $2')
        // Remove spaces around operators and delimiters (but not between alphanumeric)
        .replace(/\s*([+\-*/%=<>!~,;(){}[\]])\s*/g, '$1')
        // Restore necessary spaces after keywords
        .replace(/(local|function|if|then|else|elseif|end|for|while|do|repeat|until|return|and|or|not|in)([a-zA-Z0-9_])/g, '$1 $2')
        .trim();
    }

    return obfuscatedCode;

  } catch (error) {
    console.error("Obfuscation parsing error:", error);
    
    // Fallback to simple text-based obfuscation
    let result = code;

    if (options.removeComments) {
      result = result
        .replace(/--\[\[[\s\S]*?\]\]/g, '')
        .replace(/--[^\n]*/g, '');
    }

    if (options.minifyWhitespace) {
      result = result
        .split('\n')
        .map(line => line.trim())
        .join('\n')
        .replace(/\n+/g, '\n')
        .trim();
    }

    return result;
  }
}
