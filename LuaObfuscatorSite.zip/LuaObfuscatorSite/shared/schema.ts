import { z } from "zod";

export const obfuscationOptionsSchema = z.object({
  renameVariables: z.boolean(),
  renameFunctions: z.boolean(),
  encodeStrings: z.boolean(),
  removeComments: z.boolean(),
  minifyWhitespace: z.boolean(),
});

export type ObfuscationOptions = z.infer<typeof obfuscationOptionsSchema>;

export const obfuscateRequestSchema = z.object({
  code: z.string(),
  options: obfuscationOptionsSchema,
});

export type ObfuscateRequest = z.infer<typeof obfuscateRequestSchema>;

export const obfuscateResponseSchema = z.object({
  success: z.boolean(),
  obfuscatedCode: z.string().optional(),
  error: z.string().optional(),
});

export type ObfuscateResponse = z.infer<typeof obfuscateResponseSchema>;
