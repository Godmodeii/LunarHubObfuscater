import type { Express } from "express";
import { createServer, type Server } from "http";
import { obfuscateLuaCode } from "./obfuscator";
import { obfuscateRequestSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/obfuscate", async (req, res) => {
    try {
      const validation = obfuscateRequestSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({
          success: false,
          error: "Invalid request: " + validation.error.message,
        });
      }

      const { code, options } = validation.data;

      if (!code || code.trim().length === 0) {
        return res.status(400).json({
          success: false,
          error: "Code is required",
        });
      }

      const obfuscatedCode = obfuscateLuaCode(code, options);

      return res.json({
        success: true,
        obfuscatedCode,
      });

    } catch (error) {
      console.error("Obfuscation error:", error);
      return res.status(500).json({
        success: false,
        error: error instanceof Error ? error.message : "An error occurred during obfuscation",
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
