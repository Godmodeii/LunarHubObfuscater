import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "@/components/theme-provider";
import { Copy, Settings, Moon, Sun, Check } from "lucide-react";
import { SiDiscord } from "react-icons/si";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ObfuscateRequest, ObfuscateResponse } from "@shared/schema";

export default function ObfuscatorPage() {
  const [inputCode, setInputCode] = useState("");
  const [outputCode, setOutputCode] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();

  const [options, setOptions] = useState({
    renameVariables: true,
    renameFunctions: true,
    encodeStrings: true,
    removeComments: true,
    minifyWhitespace: true,
  });

  const obfuscateMutation = useMutation({
    mutationFn: async (request: ObfuscateRequest) => {
      const res = await apiRequest("POST", "/api/obfuscate", request);
      return await res.json() as ObfuscateResponse;
    },
    onSuccess: (data) => {
      if (data.success && data.obfuscatedCode) {
        setOutputCode(data.obfuscatedCode);
        const outputElement = document.getElementById("output-section");
        if (outputElement) {
          outputElement.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      } else {
        toast({
          title: "Obfuscation Failed",
          description: data.error || "An error occurred during obfuscation",
          variant: "destructive",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to obfuscate code",
        variant: "destructive",
      });
    },
  });

  const handleObfuscate = () => {
    if (!inputCode.trim()) {
      toast({
        title: "No Input",
        description: "Please enter some Lua code to obfuscate",
        variant: "destructive",
      });
      return;
    }
    obfuscateMutation.mutate({ code: inputCode, options });
  };

  const handleCopy = async () => {
    if (!outputCode) {
      toast({
        title: "Nothing to Copy",
        description: "Generate obfuscated code first",
        variant: "destructive",
      });
      return;
    }

    try {
      await navigator.clipboard.writeText(outputCode);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
      toast({
        title: "Copied!",
        description: "Obfuscated code copied to clipboard",
      });
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleClear = () => {
    setInputCode("");
    setOutputCode("");
    setCopySuccess(false);
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-14 items-center justify-between px-6">
          <h1 className="text-xl font-semibold text-foreground" data-testid="text-title">
            Lunar Hub Obfuscater
          </h1>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              asChild
              data-testid="button-discord"
            >
              <a
                href="https://discord.gg/wKRCmJEP9c"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Discord"
              >
                <SiDiscord className="h-5 w-5" />
              </a>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              data-testid="button-theme-toggle"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-6 py-8">
        {/* Code Editor Grid */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Input Panel */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="input-code" className="text-sm font-medium text-foreground">
              Input Code
            </Label>
            <Card className="relative flex-1 p-4">
              <Textarea
                id="input-code"
                data-testid="textarea-input"
                placeholder="-- Paste your Lua code here&#10;local function greet(name)&#10;  print('Hello, ' .. name)&#10;end&#10;&#10;greet('World')"
                value={inputCode}
                onChange={(e) => setInputCode(e.target.value)}
                className="min-h-96 resize-none border-0 font-mono text-sm leading-relaxed focus-visible:ring-0"
                spellCheck={false}
              />
            </Card>
          </div>

          {/* Output Panel */}
          <div id="output-section" className="flex flex-col gap-2">
            <Label htmlFor="output-code" className="text-sm font-medium text-foreground">
              Obfuscated Output
            </Label>
            <Card className="relative flex-1 p-4">
              <Textarea
                id="output-code"
                data-testid="textarea-output"
                placeholder="Obfuscated code will appear here..."
                value={outputCode}
                readOnly
                className="min-h-96 resize-none border-0 bg-muted/30 font-mono text-sm leading-relaxed focus-visible:ring-0"
                spellCheck={false}
              />
              {outputCode && (
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={handleCopy}
                  data-testid="button-copy-output"
                  className="absolute right-6 top-6"
                >
                  {copySuccess ? (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="mr-2 h-4 w-4" />
                      Copy
                    </>
                  )}
                </Button>
              )}
            </Card>
          </div>
        </div>

        {/* Control Bar */}
        <div className="mt-8 flex flex-col items-center gap-4">
          <div className="flex flex-col items-center gap-4">
            <Button
              size="lg"
              onClick={handleObfuscate}
              disabled={obfuscateMutation.isPending}
              data-testid="button-obfuscate"
              className="px-8 py-3"
            >
              {obfuscateMutation.isPending ? "Obfuscating..." : "Obfuscate Code"}
            </Button>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <Button
                variant="ghost"
                onClick={handleClear}
                data-testid="button-clear"
              >
                Clear Input
              </Button>
              <Button
                variant="ghost"
                onClick={handleCopy}
                disabled={!outputCode}
                data-testid="button-copy-secondary"
              >
                {copySuccess ? (
                  <>
                    <Check className="mr-2 h-4 w-4" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Output
                  </>
                )}
              </Button>
              <Button
                variant="ghost"
                onClick={() => setShowSettings(!showSettings)}
                data-testid="button-toggle-settings"
              >
                <Settings className="mr-2 h-4 w-4" />
                {showSettings ? "Hide" : "Show"} Options
              </Button>
            </div>
          </div>

          {/* Settings Panel */}
          {showSettings && (
            <Card className="w-full max-w-2xl p-6" data-testid="card-settings">
              <h3 className="mb-4 text-base font-semibold text-foreground">
                Obfuscation Options
              </h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="rename-variables"
                    checked={options.renameVariables}
                    onCheckedChange={(checked) =>
                      setOptions({ ...options, renameVariables: checked === true })
                    }
                    data-testid="checkbox-rename-variables"
                  />
                  <Label
                    htmlFor="rename-variables"
                    className="cursor-pointer text-sm text-foreground"
                  >
                    Rename variables
                  </Label>
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="rename-functions"
                    checked={options.renameFunctions}
                    onCheckedChange={(checked) =>
                      setOptions({ ...options, renameFunctions: checked === true })
                    }
                    data-testid="checkbox-rename-functions"
                  />
                  <Label
                    htmlFor="rename-functions"
                    className="cursor-pointer text-sm text-foreground"
                  >
                    Rename functions
                  </Label>
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="encode-strings"
                    checked={options.encodeStrings}
                    onCheckedChange={(checked) =>
                      setOptions({ ...options, encodeStrings: checked === true })
                    }
                    data-testid="checkbox-encode-strings"
                  />
                  <Label
                    htmlFor="encode-strings"
                    className="cursor-pointer text-sm text-foreground"
                  >
                    Encode strings
                  </Label>
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="remove-comments"
                    checked={options.removeComments}
                    onCheckedChange={(checked) =>
                      setOptions({ ...options, removeComments: checked === true })
                    }
                    data-testid="checkbox-remove-comments"
                  />
                  <Label
                    htmlFor="remove-comments"
                    className="cursor-pointer text-sm text-foreground"
                  >
                    Remove comments
                  </Label>
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="minify-whitespace"
                    checked={options.minifyWhitespace}
                    onCheckedChange={(checked) =>
                      setOptions({ ...options, minifyWhitespace: checked === true })
                    }
                    data-testid="checkbox-minify-whitespace"
                  />
                  <Label
                    htmlFor="minify-whitespace"
                    className="cursor-pointer text-sm text-foreground"
                  >
                    Minify whitespace
                  </Label>
                </div>
              </div>
            </Card>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t py-8">
        <p className="text-center text-xs text-muted-foreground" data-testid="text-footer">
          Built with{" "}
          <a
            href="https://replit.com"
            target="_blank"
            rel="noopener noreferrer"
            className="hover-elevate underline"
          >
            Replit
          </a>
        </p>
      </footer>
    </div>
  );
}
